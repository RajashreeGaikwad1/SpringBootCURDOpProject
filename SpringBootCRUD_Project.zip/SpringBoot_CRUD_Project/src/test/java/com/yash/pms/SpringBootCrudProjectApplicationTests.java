package com.yash.pms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
