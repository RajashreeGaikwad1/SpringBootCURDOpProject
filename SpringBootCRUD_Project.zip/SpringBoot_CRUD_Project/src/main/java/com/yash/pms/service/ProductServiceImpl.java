package com.yash.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yash.pms.model.Product;
import com.yash.pms.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService 
{
	@Autowired
	ProductRepository pr;

	@Override
	public Product saveProduct(Product product) 
	{
		
		return pr.save(product);
	}

	@Override
	public List<Product> getProduct()
	{
		// TODO Auto-generated method stub
		return pr.findAll();
	}

	@Override
	public Product getProductById(int pid) {
		// TODO Auto-generated method stub
		return pr.findAllByPid(pid);
	}

	@Override
	public Product updateProduct(int pid, Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteProduct(int pid) {
		pr.deleteById(pid);
		
	}

}