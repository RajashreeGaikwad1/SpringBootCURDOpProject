package com.yash.pms.service;

import java.util.List;

import com.yash.pms.model.Product;

public interface ProductService {

	Product saveProduct(Product product);

	List<Product> getProduct();

	Product getProductById(int pid);

	Product updateProduct(int pid, Product product);

	void deleteProduct(int product);

}
